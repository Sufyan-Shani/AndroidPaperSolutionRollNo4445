package hfad.com.assignmen4445;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0,v.getId(),0,"Download");
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        getMenuInflater().inflate(R.menu.navigation_item,menu);
        return true;
    }

    @Override
    public boolean onCreatePanelMenu(int featureId, @NonNull Menu menu) {
        return super.onCreatePanelMenu(featureId, menu);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Downloads");
        recyclerView = findViewById(R.id.recyclerView);

        ArrayList<PlayListsVideos> playListsVideos = new ArrayList<>();
        playListsVideos.add(new PlayListsVideos(R.drawable.num1, "Create Transparent watermark on canva|How to Make a Transparent watermark on Canva.com for Free 2021"));
        playListsVideos.add(new PlayListsVideos(R.drawable.num2, "Create Transparent watermark on canva|How to Make a Transparent watermark on Canva.com for Free 2021"));
        playListsVideos.add(new PlayListsVideos(R.drawable.num3, "Create Transparent watermark on canva|How to Make a Transparent watermark on Canva.com for Free 2021"));
        playListsVideos.add(new PlayListsVideos(R.drawable.num4, "Create Transparent watermark on canva|How to Make a Transparent watermark on Canva.com for Free 2021"));
        playListsVideos.add(new PlayListsVideos(R.drawable.num5, "Create Transparent watermark on canva|How to Make a Transparent watermark on Canva.com for Free 2021"));
        playListsVideos.add(new PlayListsVideos(R.drawable.num1, "Create Transparent watermark on canva|How to Make a Transparent watermark on Canva.com for Free 2021"));
        playListsVideos.add(new PlayListsVideos(R.drawable.num2, "Create Transparent watermark on canva|How to Make a Transparent watermark on Canva.com for Free 2021"));
        playListsVideos.add(new PlayListsVideos(R.drawable.num3, "Create Transparent watermark on canva|How to Make a Transparent watermark on Canva.com for Free 2021"));
        playListsVideos.add(new PlayListsVideos(R.drawable.num4, "Create Transparent watermark on canva|How to Make a Transparent watermark on Canva.com for Free 2021"));
        playListsVideos.add(new PlayListsVideos(R.drawable.num5, "Create Transparent watermark on canva|How to Make a Transparent watermark on Canva.com for Free 2021"));

        PlayListVideoAdapter adapter = new PlayListVideoAdapter(playListsVideos, this);
        recyclerView.setAdapter(adapter);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);



        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(this, recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                switch (position){
                    case 0:
                        Intent intent = new Intent(MainActivity.this, FirstActivity.class);
                        startActivity(intent);
                        break;
                    case 1:
                        Intent intent1 = new Intent(MainActivity.this, SecondActivity.class);
                        startActivity(intent1);
                        break;
                    case 2:
                        Intent intent2 = new Intent(MainActivity.this, ThirdActivity.class);
                        startActivity(intent2);
                        break;
                    case 3:
                        Intent intent3 = new Intent(MainActivity.this, FourthActivity.class);
                        startActivity(intent3);
                        break;
                    case 4:
                        Intent intent4 = new Intent(MainActivity.this, FifthActivity.class);
                        startActivity(intent4);
                        break;
                    case 5:
                        Intent intent5 = new Intent(MainActivity.this, SixthActivity.class);
                        startActivity(intent5);
                        break;
                    case 6:
                        Intent intent6 = new Intent(MainActivity.this, SeventhActivity.class);
                        startActivity(intent6);
                        break;
                    case 7:
                        Intent intent7 = new Intent(MainActivity.this, EighthActivity.class);
                        startActivity(intent7);
                        break;
                    case 8:
                        Intent intent8 = new Intent(MainActivity.this, NinthActivity.class);
                        startActivity(intent8);
                        break;
                    case 9:
                        Intent intent9 = new Intent(MainActivity.this, TenthActivity.class);
                        startActivity(intent9);
                        break;
                    default:
                }

            }

            @Override
            public void onLongItemClick(View view, int position) {


            }
        }));
    }
}