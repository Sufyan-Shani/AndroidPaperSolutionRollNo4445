package hfad.com.assignmen4445;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PlayListVideoAdapter extends RecyclerView.Adapter<PlayListVideoAdapter.viewHolder> {
    ArrayList<PlayListsVideos> playListsVideos;
    Context context;

    public PlayListVideoAdapter(ArrayList<PlayListsVideos> playListsVideos, Context context) {
        this.playListsVideos = playListsVideos;
        this.context = context;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.sample_recyclerview,parent,false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {
        PlayListsVideos vediospic = playListsVideos.get(position);
        holder.imageView.setImageResource(vediospic.getPicture());
        holder.textView.setText(vediospic.getText());
        ((Activity)context).registerForContextMenu(holder.cardView);

        switch (position){
            case 0:
                holder.imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(context,"item one is clicked",Toast.LENGTH_SHORT).show();
                    }
                });
                holder.textView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(context,"Item One is clicked",Toast.LENGTH_SHORT).show();
                    }
                });
                break;

            default:
        }

    }

    @Override
    public int getItemCount() {
        return playListsVideos.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        TextView textView;
        CardView cardView;

        public viewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            textView = itemView.findViewById(R.id.textView);
            cardView = itemView.findViewById(R.id.cardView);
        }
    }
}
