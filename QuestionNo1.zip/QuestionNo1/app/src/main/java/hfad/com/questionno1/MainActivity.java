package hfad.com.questionno1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button dialogButton;
    String selectedCourse="java";
    final String[] courses={"Java", "Python", "Android", "Angular JS"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dialogButton=findViewById(R.id.dialogButton);
        dialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });
    }
    public void openDialog(){

        AlertDialog.Builder builder= new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Select Your Course");
        builder.setSingleChoiceItems(courses, 1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                selectedCourse = courses[which];
                Toast.makeText(MainActivity.this, "You Select The:"+ selectedCourse, Toast.LENGTH_LONG).show();
            }
        });

        builder.setPositiveButton("Get Selected Course", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent= (Intent) new Intent(MainActivity.this, SecondActivity.class);
                startActivity(intent);
            }
        });
        builder.show();
    }
}