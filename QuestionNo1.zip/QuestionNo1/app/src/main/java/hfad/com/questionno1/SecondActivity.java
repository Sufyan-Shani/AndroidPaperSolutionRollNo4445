package hfad.com.questionno1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SecondActivity extends AppCompatActivity {
    private String selectedCourse;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        selectedCourse = getIntent().getExtras().getString("SELECTED_COURSE");
        getSupportActionBar().setTitle(selectedCourse);
    }
}